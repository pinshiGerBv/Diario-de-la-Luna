export class CreateAiDto {}
