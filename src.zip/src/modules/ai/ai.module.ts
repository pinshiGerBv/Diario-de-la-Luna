import { Module } from '@nestjs/common';

import { HttpModule } from '@nestjs/axios';

import { AiService } from './ai.service';
import { AiController } from './ai.controller';

@Module({
  // =========================
  // IMPORTS
  // =========================
  imports: [
    HttpModule.register({
      timeout: 120000,
      maxRedirects: 5,
    }),
  ],

  // =========================
  // CONTROLLERS
  // =========================
  controllers: [AiController],

  // =========================
  // PROVIDERS
  // =========================
  providers: [AiService],

  // =========================
  // EXPORTS
  // =========================
  exports: [AiService],
})
export class AiModule {}
