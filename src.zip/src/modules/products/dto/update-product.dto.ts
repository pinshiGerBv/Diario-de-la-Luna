export class UpdateProductDto {}
