import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

import * as dotenv from 'dotenv';

dotenv.config();

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // 👑 CONFIGURACIÓN DE CORS COMPLETA PARA TU PROYECTO
  app.enableCors({
    origin: [
      'http://localhost:4200',
      'https://la-reina-del-mezcal.web.app', // 👈 Tu URL oficial de Firebase
    ],
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
    credentials: true,
  });

  // Acceso directo compatible con Render sin lanzar el error de tipos de Node
  const port = (globalThis as any).process?.env?.PORT || 3000;
  await app.listen(port);

  console.log(`🚀 Backend ejecutándose en el puerto: ${port}`);
}

bootstrap();
